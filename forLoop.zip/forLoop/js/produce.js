var produce = ["egg", "corn", "carrot", "apple", "orange"];
var display = document.getElementById("display");
listCode = "";
unorderedList =  "<ul>"+listCode+"</ul>"
var i;
console.log(produce);
document.getElementById("display").innerHTML = produce;

function decItems (){
    for (i=0; i < produce.length; i++) {
        var listItem = "<li>" + i + ": "+ produce[i] + "</li>"; 
        listCode+=listItem;
    }   
return listCode;
}

function impItems(){
    produce.forEach((item, i) => {

        var listItem = "<li>" + i + ": "+ item + "</li>";
    
        listCode+=listItem;
    
        return listCode;
    
      });
}


function updateCode(codeType){
    listCode = ""

    if (codeType == 'Declarative') {
  
      decItems()
  
    } if (codeType == 'Imperative') {
  
      impItems()
  
    }
  
    else {
  
      console.log('What is your codeType?!')
  
    }
  
    unorderedList = "<p>"+ codeType +"</p><ul>"+listCode+"</ul>";
  
    display.innerHTML = unorderedList ;
}





document.getElementById('decBTN').addEventListener('click',()=>{updateCode('Declarative'); console.log("clicked")})
document.getElementById('impBTN').addEventListener('click',()=>{updateCode('Imperative'); console.log("clicked")})

console.log(produce, listCode)